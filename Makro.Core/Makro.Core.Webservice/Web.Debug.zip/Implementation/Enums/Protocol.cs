﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Makro.Core.Webservice.Implementation.Enums
{
    public enum Protocol
    {
        http, 
        https 
    }
}